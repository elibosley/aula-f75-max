Lumi / F75 Max companion pack

Twelve 80x80 RGB565 frames with transparent color 0000.
Byte order: little endian. Frame order is in manifest.json.
pet_assets.h contains only the original six poses and uses the existing renderer names and sizes.
The integrated firmware bank supports all four characters and twelve poses each.
It replaces the single compiled character; do not add all headers together.
A firmware rebuild, standard validation and guarded installation are required.
This ZIP is artwork and source data, not a flashable keyboard image.
Live character upload is not implemented. Never send this data to the radio.
